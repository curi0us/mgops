<?php
$url = $_SERVER["REQUEST_URI"];
if($url=='/') {include 'index.php';die;}
$sRequest = substr($url.'?',0, strpos($url.'?','?'));

$requestedFile = $url;
if(strrpos($requestedFile,'/') !== FALSE) $requestedFile = substr($requestedFile, strrpos($requestedFile,'/'));	if(strrpos($requestedFile,'.') !== FALSE) $requestedFile = substr($requestedFile, 0, strrpos($requestedFile,'.'));

//MGO1 Policy Request
if(strstr($url, 'policy')) echo file_get_contents('policy.txt');
else {
	switch(strtolower($requestedFile)) {
		case '/reguser':
			include "reguser.php";
			break;
		case '/deluser':
			include "deluser.php";
			break;
		case '/chgpswd':
			include 'chgpswd.php';
			break;
		default:
			echo '1';
	}
}

?>
