<?php
include 'dbcon.php';
if(!isset($_REQUEST['name'])||!isset($_REQUEST['passwd'])||!isset($_REQUEST['pname'])) {
        echo '1';
        die();
}

$name = $_REQUEST['name'];
$pname = $_REQUEST['pname'];

//Salt comes from the server, md5() is a bad choice for passwords but its what Konami did, don't blame me
$pass = md5($_REQUEST['name']."\x84\xbd\xb8\xcf\xad\x46\xdd\x6e\x42\x4a\xe4\xd8\xd2\x6a\x12\xf3".$_REQUEST['passwd']);


$oStmt = DB::query('SELECT * FROM users WHERE username=? or displayname=?',$name,$pname);
$rows = $oStmt->fetchAll();
if(count($rows) != 0) {
	echo '1';
	die();
}

$oStmt = DB::query('INSERT into users(`username`,`displayname`,`password`) VALUES(?,?,?)', $name, $pname, $pass);
if(DB::lastInsertId()==0) {
        echo '1';
        die();
}

echo 0;

?>
