<?php
include 'dbcon.php';
if(!isset($_REQUEST['name'])||!isset($_REQUEST['passwd'])||!isset($_REQUEST['pswdnew'])) {
        echo '1';
        die();
}

$name = $_REQUEST['name'];
//These bytes come from the value the server provides during authentication, basicaly they are magic
//Its also not a good idea to store md5s (even if salted) for passwords...but its what they do
$pass = md5($_REQUEST['name']."\x84\xbd\xb8\xcf\xad\x46\xdd\x6e\x42\x4a\xe4\xd8\xd2\x6a\x12\xf3".$_REQUEST['passwd']);
$passNew = md5($_REQUEST['name']."\x84\xbd\xb8\xcf\xad\x46\xdd\x6e\x42\x4a\xe4\xd8\xd2\x6a\x12\xf3".$_REQUEST['pswdnew']);

$oStmt = DB::query("SELECT * FROM users WHERE username=? AND password=?", $name, $pass);
$rows = $oStmt->fetchAll();
if(count($rows)!=1) {
        echo '1';
        die();
}


DB::query("UPDATE users SET password=?, secret='', secret2='', ip=? WHERE username=? AND password=? LIMIT 1", $passNew, $_SERVER['REMOTE_ADDR'], $name, $pass);

echo 0;
?>
