<?php 
/** 
 * Simple Database wrapper 
 */ 
class DB { 
    static private $iCount = 0; //Query counter 
    private static $con = null; //Connection variaible 
         
    //Connection information 
    const USER = '**redacted**'; 
    const PASS = '**redacted**'; 
    const CONNECTION_STRING = '**redacted**'; 

    /** 
     * Grabs the id of the last inserted row 
     */ 
    static function lastInsertId() { 
        return self::$con->lastInsertId();     
    } 
     
    /** 
     * Static function to access the query counter 
     */ 
    static function getQueryCount() { 
        return self::$iCount;     
    } 
     
    /** 
     * Runs a prepared query with the supplied arguments 
     * @param $sQuery - The query to run 
     * @param $aArgs - Array of arguments for the query 
     */ 
    static function query() { 
        //If not already connected establish a connection 
        if(self::$con == null) { 
            try { 
                self::$con = new PDO(self::CONNECTION_STRING,self::USER,self::PASS); 
                //Set attributes 
                self::$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
                self::$con->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC); 
            } catch (PDOException $e) { 
                //Rewrite the Database exception to a Forum exception 
                echo $e->getMessage(); 
                throw new Exception('Unable to connect to database',SiteConfig::$CODES['DB_ERROR']); 
            } 
        } 
        $sQuery = ""; $aArgs=null; 
        $aFuncArgs = func_get_args(); 
        switch(count($aFuncArgs)) { 
            case 0: 
                throw new Exception("Must provide a query to DB::query()",SiteConfig::$CODES['DB_ERROR']); 
                break; 
            case 1: //No arguments to prepare in query 
                $sQuery = $aFuncArgs[0]; 
                $aArgs  = null;  
                break; 
            case 2: //single argument, either already an array for prepare or make into an array 
                $sQuery = $aFuncArgs[0]; 
                if(is_array($aFuncArgs[1])) $aArgs = $aFuncArgs[1];    
                else $aArgs = array($aFuncArgs[1]); 
                break; 
            default: //Multiple arguments, turn them into an array 
                $sQuery = $aFuncArgs[0];  
                for($i=1;$i<count($aFuncArgs);$i++) $aArgs[] = $aFuncArgs[$i]; 
        } 
         
         
        //Execute the query 
        $oStmt = null; 
        try { 
            $oStmt = self::$con->prepare($sQuery); 
            if($aArgs==null) $oStmt->execute(); 
            else $oStmt->execute($aArgs); 
        } catch(PDOException $e) { 
            //Prepare exception string 
            if($aArgs==null) $sArgs = ''; 
            else $sArgs = implode(',',$aArgs); 
            throw new Exception('Query Failed: "'.$sQuery.'", Args: '.$sArgs,ForumsConfig::$CODES['DB_ERROR'],$e); 
        }     
         
        self::$iCount++;    //Query was successful for increment the counter     
        return $oStmt;         
    } 
} 

?>
